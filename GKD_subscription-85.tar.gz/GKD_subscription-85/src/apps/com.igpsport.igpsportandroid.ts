import { defineGkdApp } from '@gkd-kit/define';

export default defineGkdApp({
  id: 'com.igpsport.igpsportandroid',
  name: 'iGPSPORT',
  groups: [
    {
      key: 1,
      name: '更新提示',
      actionMaximum: 1,
      resetMatch: 'app',
      rules: '@[text="忽略本次"] + [text="立即升级"]',
      snapshotUrls: 'https://i.gkd.li/i/13797203',
    },
  ],
});
